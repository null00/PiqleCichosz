/** An autonomous agent wandering into a closed environment 

Reward is due when the treasure is found.

*/

import agents.IAgent;
import agents.LoneAgent;
import mazes.*;
import referees.OnePlayerReferee; 
import algorithms.*;





public class SimpleMazeExample{


    public static void main(String args[])throws Exception{
	// A maze surrounding with walls 
	int taille=20; 

	Maze cnossos=new Maze(taille,taille); 
	// Maze design
	// 0 : free cell
	// 1 : wall
	// 2: treasure

	/* Central cross maze */
	// first, an empty maze
	int design[][]=new int[taille][]; 
	for(int i=0;i<taille;i++) {
	    design[i]=new int[taille]; 
	    for(int j=0;j<taille;j++)  design[i][j]=0;
	} 
	// Horizontal part of the cross
	for(int i=((taille+1)/3);i<(2*(taille/3));i++)
	    for(int j=3;j<taille-2;j++) design[i][j]=1;
	// Vertical part of the cross
	for(int j=(taille+1)/3;j<(2*(taille/3));j++)
	    for(int i=2;i<taille-2;i++) design[i][j]=1;
	
	design[2][2]=2; 
	
	
	cnossos.setDesign(design); 
	// Choose algorithm
	QLearningSelector sql=new QLearningSelector(); 
	

	// Control exploration/exploitation
	double epsilon=0.3; 
	sql.setEpsilon(epsilon); 
	sql.setGamma(1);
	//sql.setAlphaDecayPower(0.5);     // A utiliser pour Watkins
	//sql.setGeometricAlphaDecay();  // Ne marche pas pour Watkins

	// Build agent
	IAgent zero07=new LoneAgent(cnossos,sql); 

	// Call referee
	OnePlayerReferee arbitre=new OnePlayerReferee(zero07); 
	// Length of episode
	arbitre.setMaxIter(300); 
	//arbitre.setGraphical();
	// Start wandering in the maze
	double reward=0;
	int tailleEpisode=10; 
	//arbitre.setGraphical();
	for(int episode=1;episode<10000;episode++){
		if(episode==9000)arbitre.setGraphical();
	    cnossos.randomInitialState(); 
	    arbitre.episode(cnossos.defaultInitialState()); 
	    reward+=arbitre.getRewardForEpisode();  
	    if((episode%tailleEpisode==0) &&(episode!=0))
		{
		    System.out.println(episode+" "+ (reward/(0.0+tailleEpisode))+" "+epsilon); 
		    // System.out.println("Episode : "+episode+" Average reward :"+ (reward/(0.0+tailleEpisode))); 
		    reward=0.0; 
		}
	    epsilon*=0.9999;
	    sql.setEpsilon(epsilon); 
	}
    }
}
